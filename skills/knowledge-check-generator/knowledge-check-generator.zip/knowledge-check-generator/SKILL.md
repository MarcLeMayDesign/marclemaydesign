---
name: knowledge-check-generator
description: This skill generates multiple-choice assessment questions from a provided source, such as a learning module or instructional document. Each question includes answer options (four by default), with feedback given for each. Use when user types "write a quiz", "generate a quiz", "create some questions", "make a knowledge check", "generate multiple-choice", and similar phrases. Do not use for reviewing existing questions.
---

<!-- An independent learning project. Not affiliated with Conscious Discipline or Loving Guidance, Inc., but reviewed by a Certified Conscious Discipline Instructor.
Content adapted from Conscious Discipline www.ConsciousDiscipline.com 800-842-2846 -->

# Knowledge Check Generator

Generates multiple-choice questions that focus on assessing how a learner uses critical thinking to solve a task, rather than assessing based on rote recall. Feedback for each option gives the learner a clear sense of where they are strong and where they might need to review the materials before moving on. This helps the course designer generate questions that can easily be dropped into a learning module.

## Inputs
- Source document or module; if no source given, ask for it
- Who the learners are; if no information on learners given, infer from the source and say what you assumed
- What are the overall learning objectives; if none given, infer from the source and say what you assumed
- Goal or task of the specific question; if not given, take the tasks from the source and learning objectives
- How many answer options per question; if no number is specified, default to four answer options
- How many questions are needed; if no number is specified, start by generating three and follow up to ask the user how many more they'd like

Ask for everything missing in one message.

## Steps
1. Pull from the source the tasks it teaches a learner to do
2. Choose the most important tasks, one per question (see Inputs for how many); generate one scenario per task. If there are fewer tasks than the number of questions requested in Inputs, repeat the most important tasks across multiple questions, with a new scenario each time
3. Write the question stem
4. Write the correct answer: it should be tied to a specific line or lines from the source; check each correct answer with its source line; if the wording matches, rephrase it
5. Write other answer options: wrong answer options should come from real mistakes or misunderstandings a learner might make, not just something false
6. Write feedback for each answer option
7. Check each question against the question and feedback rules and fix any that break a rule before reporting. Check especially for a key word shared by the scenario or stem and only the correct answer

## Question rules
- No "all/none of the above" options allowed: these are a multiple-choice cheat that doesn't test real learning
- No negative stems (NOT, EXCEPT) or double negatives: each stem should guide the learner, not force them to think in negations
- Each question tests only a single task: this helps make each question pointed and direct, and aligns with the purpose
- Each question approaches the task in a way that requires the learner to think critically or solve a problem scenario, rather than rely on rote recall: rote recall is the lowest level on Bloom's taxonomy of learning; we want to test higher levels of critical thinking; this is also in keeping with Knowles's Andragogy Principle regarding problem-centered learning
- Stems should not share a key word with only the right option: learners can match words instead of using the source
- Scenarios must only use what the source says: an added detail can make a wrong answer defensibly correct
- Correct answers should not be copied verbatim from the learning module: this makes a correct answer more like rote recall
- Vary the letter position of the correct answer so there is no clear pattern: a clear pattern lets learners guess
- Options should be roughly the same length: an option that is much shorter or longer than the others can stand out as obviously correct
- Options should be worded in similar structures and tenses: so that no single option stands out as obviously different
- Wrong answers should be realistic options, and not deliberately obfuscating: don't insult the learner's intelligence, rather challenge them to really think through each option
- Stems must be written as complete sentences, but answers can be fragments: this is simply to make the questions flow better
- Questions must be written in plain language: to avoid overly confusing jargon or obfuscating language
- Questions must not be deliberately misleading: the goal is not to trick the learner, rather challenge them to think through the task realistically
- Only one option can be defensibly correct: two right answers make the question unfair, and the learner can't show what they know

## Feedback rules
- Each option must have its own feedback: this is in keeping with a number of adult learning principles, including the ARCS model's Confidence and Satisfaction, as well as Gagné's "Provide Feedback" event
- Feedback should be drawn only from the source material, and not state anything that the source does not say: this helps keep the learning objectives, the learning itself, and the assessments aligned
- Wrong-answer feedback names the error, provides warm constructive critique, and points back to where in the module the learner could review to understand the feedback better; this aids in Gagné's "Enhance retention and transfer" event
- Right-answer feedback says "Correct", and follows up warmly with an explanation of why it is correct; this aids in Gagné's "Enhance retention and transfer" event

## Output format
- A preamble that states anything assumed from the Inputs process
- Per question: scenario, stem, answer options (listed with capital letters), correct answer letter, feedback for each option (labeled by its letter, 1-3 sentences only), and the verbatim source line it tests
- Nothing else: no summary, no notes on how the generated questions and feedback connect to the question and feedback rules; except a preamble, if needed, and a prompt to ask the user if and how many more questions they would like, and for anything they'd like to change

## Example
Source: https://marclemaydesign.com/module/#lrn-11, https://marclemaydesign.com/module/#lrn-12, https://marclemaydesign.com/module/#lrn-31
Source lines: 
- The Survival State: The oldest parts of the brain, working below awareness to keep us safe. Under threat, the brain drops here. Skillset: fight, flight, or freeze (surrender). Nothing else.
- The Emotional State: Emotions are in control, and rational thinking is almost impossible. It draws on mental models learned through our upbringing and experience, rather than conscious thought. Skillset: unconsciously accessing long-term memory, feeling emotions, assigning blame and making judgments
- Anyone can drop a state, and it can happen fast, especially if you are at low capacity. Capacity is your store of emotional and social energy. Yours can drain after a long day at work, or unbroken hours of childcare. Your child’s can drain just from holding it together all day at school.
- The Survival State: Drops to Survival when: you experience a real threat, or even an irritation that feels like one, or your capacity has run out.
- Noticing your child’s state starts with empathy: understanding, without judgment. You’re looking for what they feel, not trying to stop it. Each state shows up in a child in its own way, and each one is asking a question. Read below to see signs and behaviors to look for to figure out your child’s state. The Survival State “Am I safe?” Fight: hitting, kicking, biting, screaming, tantrums. Flight: running off, hiding. Freeze: going limp, crying, giving up, or going along without taking anything in. 
- The Emotional State “Am I loved?” This one shows up mostly in words. Blaming, name-calling, “you never,” denying it happened, pulling away from you.

You are in the grocery store with your five-year-old after a long day at school. He's begging for candy, and when you say "no," he lashes out at the nearest item: a jar of pickles. It smashes to the ground, and he flees down the aisle, screaming "It's not fair!!"

What brain state is your child in, and what clues helped you determine that?
A. Emotional State: he's telling you his feelings and yelling
B. Survival State: he's being physically violent and running away
C. Emotional State: he's tired after a long day of school
D. Survival State: he's annoyed at not getting any candy

Correct Answer Letter: B

Feedback:
A: You're close. He is expressing some feelings, but in the Emotional State, feelings are usually expressed with words. The screaming is a fight response. Consider checking the signs of each brain state again.
B: Correct. Survival State puts the child into fight-or-flight mode: smashing the pickles is a fight response, running down the aisle is the flight.
C: Not quite. While low capacity after a long day can contribute to a drop in brain state, it's a cause of a drop, not a sign of what state your child is in. Consider checking the signs of each brain state again.
D: You're close. It is Survival State, but annoyance isn't sufficient alone to suggest Survival State; it could simply be a response from the Emotional State. Consider checking the signs of Survival State again.
